﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MultiAuthMvc.Models
{
    public class ProjectDbContext:DbContext
    {
        public DbSet<Admin> Admins { get; set; }
        public DbSet<DocReader> DocReaders { get; set; } 
    }
}