﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Web;
using System.Web.Mvc;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Microsoft.Office.Interop.Word;
using MultiAuthMvc.Models;
using Path = iTextSharp.text.pdf.parser.Path;

namespace MultiAuthMvc.Controllers
{
    public class HomeController : Controller
    {
        ProjectDbContext db=new ProjectDbContext();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
      
        public ActionResult GetTextFromPDF()
        {
            string path = Server.MapPath("~/Files/Read.pdf");

            StringBuilder text = new StringBuilder();
            using (PdfReader reader = new PdfReader(path))
            {

                
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                }
            }
            DocReader aReader=new DocReader();
            aReader.FileName = "~/Files/Read.pdf";
            db.DocReaders.Add(aReader);
            db.SaveChanges();
            ViewBag.Content = text;
            return View();
        }

        public ActionResult GetTextFromWord()
        {
            StringBuilder text = new StringBuilder();
            Application word = new Application();
            object miss = System.Reflection.Missing.Value;
            object path = @"D:\Read.docx";
            object readOnly = true;
            Microsoft.Office.Interop.Word.Document docs = word.Documents.Open(ref path, ref miss, ref readOnly, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss);

            for (int i = 0; i < docs.Paragraphs.Count; i++)
            {
                
                    text.Append(" \r\n " + docs.Paragraphs[i + 1].Range.Text);
            }
            ViewBag.Content = text;
            return View();
        }

        public ActionResult GetTextFromText()
        {
            string text = System.IO.File.ReadAllText(@"D:\Read.txt");

            ViewBag.Content = text;
            return View();
        }


        public ActionResult SaveFile()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SaveFile(HttpPostedFileBase postedFile) 
        {
            if (postedFile != null)
            {
                string path = Server.MapPath("~/Files/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                postedFile.SaveAs(path + postedFile.FileName);
                DocReader aReader = new DocReader();
                aReader.FileName =DateTime.Now.ToFileTime()+"_"+postedFile.FileName;
                db.DocReaders.Add(aReader);
                db.SaveChanges();
                ViewBag.Message = "File uploaded successfully.";
            }

            return View();
        }
    }
}