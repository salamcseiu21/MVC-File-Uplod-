﻿using System;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Microsoft.Office.Interop.Word;
using MultiAuthMvc.Models;
using Path = System.IO.Path;

namespace MultiAuthMvc.Controllers
{
    public class FileReaderController : Controller
    {
        private ProjectDbContext db = new ProjectDbContext();

        // GET: /FileReader/
        public ActionResult Index()
        {
            return View(db.DocReaders.ToList());
        }

        // GET: /FileReader/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DocReader docreader = db.DocReaders.Find(id);
            if (docreader == null)
            {
                return HttpNotFound();
            }
            
            StringBuilder text = new StringBuilder();
            if (docreader.FileName.Contains(".pdf"))
            {
                string path = Server.MapPath("~/Files/" + docreader.FileName);
                using (PdfReader reader = new PdfReader(path))
                {

                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                    }
                }
                docreader.Content = text.ToString();
            }
            else if (docreader.FileName.Contains(".docx") || docreader.FileName.Contains(".doc"))
            {
                Application word = new Application();
                object miss = System.Reflection.Missing.Value;
                object path = Server.MapPath("~/Files/" + docreader.FileName);
                object readOnly = true;
                Document docs = word.Documents.Open(ref path, ref miss, ref readOnly, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss);

                for (int i = 0; i < docs.Paragraphs.Count; i++)
                {

                    text.Append(" \r\n " + docs.Paragraphs[i + 1].Range.Text);
                }
                docreader.Content = text.ToString();
            }
            
            else if (docreader.FileName.Contains(".txt"))
            {
                string path = Server.MapPath("~/Files/" + docreader.FileName);
                docreader.Content = System.IO.File.ReadAllText(path);
            }
           
            return View(docreader);
        }

        // GET: /FileReader/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /FileReader/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(DocReader docreader, HttpPostedFileBase postedFile)
        {

            if (postedFile != null)
            {
                string path = Server.MapPath("~/Files/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                string ext = Path.GetExtension(postedFile.FileName);
                string fileName = Guid.NewGuid().ToString().Replace("-", "").ToUpper() + ext;
                postedFile.SaveAs(path + fileName);
                DocReader aReader = new DocReader
                {
                    FileName = fileName,
                    UploadedAt = DateTime.Now,
                    Title = docreader.Title
                };
                db.DocReaders.Add(aReader);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            

            return View(docreader);
        }

        // GET: /FileReader/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DocReader docreader = db.DocReaders.Find(id);
            if (docreader == null)
            {
                return HttpNotFound();
            }
            return View(docreader);
        }

        // POST: /FileReader/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,Title,FilePath")] DocReader docreader)
        {
            if (ModelState.IsValid)
            {
                db.Entry(docreader).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(docreader);
        }

        // GET: /FileReader/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DocReader docreader = db.DocReaders.Find(id);
            if (docreader == null)
            {
                return HttpNotFound();
            }
            return View(docreader);
        }

        // POST: /FileReader/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DocReader docreader = db.DocReaders.Find(id);
            db.DocReaders.Remove(docreader);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public FileResult OpenPDF()
        {
            return File(Server.MapPath("~/Files/33989AB543374D47B9CEC4760737A7A3.pdf"), "application/pdf");
        }

        public FileResult DisplayPDF()
        {
            string filepath = Server.MapPath("~/Files/33989AB543374D47B9CEC4760737A7A3.pdf");
            byte[] pdfByte = GetBytesFromFile(filepath);
            return File(pdfByte, "application/pdf");
        }
        public byte[] GetBytesFromFile(string fullFilePath)
        {
            // this method is limited to 2^32 byte files (4.2 GB)
            FileStream fs = null;
            try
            {
                fs = System.IO.File.OpenRead(fullFilePath);
                byte[] bytes = new byte[fs.Length];
                fs.Read(bytes, 0, Convert.ToInt32(fs.Length));
                return bytes;
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }
            }
        }
    }
}
