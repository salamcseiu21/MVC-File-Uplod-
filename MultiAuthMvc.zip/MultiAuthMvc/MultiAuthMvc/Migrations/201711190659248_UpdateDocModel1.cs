namespace MultiAuthMvc.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateDocModel1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.DocReaders", "FileName", c => c.String());
            AddColumn("dbo.DocReaders", "Content", c => c.String());
            AddColumn("dbo.DocReaders", "UploadedAt", c => c.DateTime(nullable: false));
            DropColumn("dbo.DocReaders", "FilePath");
        }
        
        public override void Down()
        {
            AddColumn("dbo.DocReaders", "FilePath", c => c.String());
            DropColumn("dbo.DocReaders", "UploadedAt");
            DropColumn("dbo.DocReaders", "Content");
            DropColumn("dbo.DocReaders", "FileName");
        }
    }
}
