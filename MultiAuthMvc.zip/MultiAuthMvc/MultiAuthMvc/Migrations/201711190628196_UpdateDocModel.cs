namespace MultiAuthMvc.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateDocModel : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.DocReaders", "Title", c => c.String());
            AddColumn("dbo.DocReaders", "FilePath", c => c.String());
            DropColumn("dbo.DocReaders", "Content");
        }
        
        public override void Down()
        {
            AddColumn("dbo.DocReaders", "Content", c => c.String());
            DropColumn("dbo.DocReaders", "FilePath");
            DropColumn("dbo.DocReaders", "Title");
        }
    }
}
